README.md
# Meta-Script Generator (scaffold.py)

## Description
This program generates a basic Python script template.  
It is designed to help quickly create small, well-structured scripts
commonly used in bioinformatics pipelines.

## Features
- Prompts for an output filename
- Prevents overwriting existing files
- Generates a Python script with:
  - Shebang line
  - `import sys`
  - `main()` function
  - `if __name__ == "__main__"` execution guard
  - Example I/O using `sys.stdout.write()` and `sys.stderr.write()`

## Usage
```bash
python3 scaffold.py
